<?php

namespace MegaGastPvP\FacUI;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use jojoe77777\FormAPI;
use pocketmine\utils\TextFormat as c;
use pocketmine\Player;
use pocketmine\plugin\PluginManager;
use pocketmine\Server;

class Main extends PluginBase implements Listener {
    public function onEnable(){
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool {
        switch($cmd->getName()){
            case "fac":
                if($sender instanceof Player){
                    $a = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
                    if($a === null || $a->isDisabled()){
                        
                    }
                    $f = $a->createSimpleForm(function (Player $sender, array $data){
                    $r = $data[0];
                    if($r === null){
                        
                    }
                    switch($r){
                        case 0:
                               $command = "fac claim";
                               $this->getServer()->getCommandMap()->dispatch($sender, $command);
                               break;
                        case 1:
                               $command = "fac overclaim";
                               $this->getServer()->getCommandMap()->dispatch($sender, $command);
                               break;
                        case 2:
                               $command = "fac unclaim";
                               $this->getServer()->getCommandMap()->dispatch($sender, $command);
                               break;
                        case 3:
                               $command = "fac topfactions";
                               $this->getServer()->getCommandMap()->dispatch($sender, $command);
                               break;
                        case 4;
                               $command = "fac del";
                               $this->getServer()->getCommandMap()->dispatch($sender, $command);
                               break;
                        case 5;
                               $command = "fac leave";
                               $this->getServer()->getCommandMap()->dispatch($sender, $command);
                               break;
                        case 6;
                               $command = "fac home";
                               $this->getServer()->getCommandMap()->dispatch($sender, $command);
                               break;
                        case 7;
                               $command = "fac unsethome";
                               $this->getServer()->getCommandMap()->dispatch($sender, $command);
                               break;
                        case 8;
                               $command = "fac ourmembers";
                               $this->getServer()->getCommandMap()->dispatch($sender, $command);
                               break;
                        case 9;
                               $command = "fac ourofficers";
                               $this->getServer()->getCommandMap()->dispatch($sender, $command);
                               break;
                        case 10;
                                $command = "fac ourleader";
                                $this->getServer()->getCommandMap()->dispatch($sender, $command);
                                break;
                        case 11;
                                $command = "fac c";
                                $this->getServer()->getCommandMap()->dispatch($sender, $command);
                                break;
                    }
                    });
                    $form->setTitle(c::GOLD . "Faction Commands");
                    $form->setContent(c::AQUA . "What Command Will you run?");
                    $form->addButton(c::RED . "Claim");
                    $form->addButton(c::RED . "OverClaim");
                    $form->addButton(c::RED . "UnClaim");
                    $form->addButton(c::RED . "Top Factions");
                    $form->addButton(c::RED . "Delete");
                    $form->addButton(c::RED . "Leave");
                    $form->addButton(c::RED . "home");
                    $form->addButton(c::RED . "unsethome");
                    $form->addButton(c::RED . "MyMembers");
                    $form->addButton(c::RED . "MyOfficers");
                    $form->addButton(c::RED . "MyLeader");
                    $form->addButton(c::RED . "FactionChat");
                    $form->sendToPlayer($sender);
                }
            break;    
        }
        return true;
    }
}